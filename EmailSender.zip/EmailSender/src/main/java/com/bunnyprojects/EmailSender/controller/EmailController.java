package com.bunnyprojects.EmailSender.controller;

import com.bunnyprojects.EmailSender.dto.EmailRequest;
import com.bunnyprojects.EmailSender.service.EmailService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/email")
@RequiredArgsConstructor
public class EmailController {
    @Autowired
    private EmailService emailService;

    @PostMapping("/send")
    public ResponseEntity<String> sendEmail( @Valid  @RequestBody EmailRequest emailRequest){
        return ResponseEntity.ok(emailService.sendEmail(emailRequest));
    }
}
