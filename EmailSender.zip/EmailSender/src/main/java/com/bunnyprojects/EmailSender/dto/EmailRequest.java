package com.bunnyprojects.EmailSender.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class EmailRequest {
    @NotBlank(message = "Recipient is required")
    private String  recipient; //Recipientemail to send to
    @NotBlank(message = "Subject or email title is required")
    private String subject; //title
    private String body;

    public @NotBlank(message = "Recipient is required") String getRecipient() {
        return recipient;
    }

    public void setRecipient(@NotBlank(message = "Recipient is required") String recipient) {
        this.recipient = recipient;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public @NotBlank(message = "Subject or email title is required") String getSubject() {
        return subject;
    }

    public void setSubject(@NotBlank(message = "Subject or email title is required") String subject) {
        this.subject = subject;
    }
}
